This save-data is from the older/original multiplayer save-data hack (ISZ-Hack-Tool).


Just a reminder that you NEED to close steam if you prefer to do this manually.
That way it won't overwrite your old save-data and restore it (deleting the hacked save).

Thanks For All of Your Support on GitHub - Cracko298